connect system/manager
spool para.lst
sho parameter
spool off
exit
