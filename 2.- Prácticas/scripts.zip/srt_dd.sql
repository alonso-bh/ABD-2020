-- srt_dd.sql
-- Use for Lab 11 Q3 O8DBA class

SELECT object_name
FROM dba_objects
UNION
SELECT segment_name
FROM dba_segments
/
