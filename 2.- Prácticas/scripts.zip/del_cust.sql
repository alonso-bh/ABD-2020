DELETE FROM system.customers
WHERE cust_code >= 'B01';

COMMIT;
