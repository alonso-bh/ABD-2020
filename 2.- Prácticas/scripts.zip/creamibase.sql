-- File:         credb.sql

-- Ejemplo de script para la creacion de una base de datos para el curso
-- Administracion de Bases de Datos Oracle
-- Fecha: 07-JUNIO-2003

-- Editad lo siguiente para especificar los valores adecuados:
-- Cambiad <home-directory>\init<SID>.ora en el comando startup para 
--		especificar el nombre del fichero de parametros
-- 	<database-name> en el comando create database para especificar el nombre
--      de base de datos correcto
-- 	<home-directory> al directorio home de vuestra cuenta en el servidor
spool c:\oracle\admin\mibase\create\creabd.log
STARTUP NOMOUNT PFILE="c:\oracle\admin\mibase\pfile\initmibase.ora";



CREATE DATABASE mibase
USER SYS IDENTIFIED BY cursodba
USER SYSTEM IDENTIFIED BY cursodba
   LOGFILE GROUP 1 ('c:\oracle\oradata\mibase\redo01.log') SIZE 10M,
           GROUP 2 ('c:\oracle\oradata\mibase\redo02.log') SIZE 10M,
           GROUP 3 ('c:\oracle\oradata\mibase\redo03.log') SIZE 10M
   MAXLOGFILES 5
   MAXLOGMEMBERS 5
   MAXLOGHISTORY 1
   MAXDATAFILES 100
   MAXINSTANCES 1
   CHARACTER SET US7ASCII
   NATIONAL CHARACTER SET AL16UTF16
   DATAFILE 'c:\oracle\oradata\mibase\system01.dbf' SIZE 350M REUSE
   EXTENT MANAGEMENT LOCAL
   DEFAULT TEMPORARY TABLESPACE temp
      tempfile 'c:\oracle\oradata\mibase\temp01.dbf' 
      SIZE 20M REUSE
   UNDO TABLESPACE undotbs 
      DATAFILE 'c:\oracle\oradata\mibase\undotbs01.dbf'
      SIZE 50M REUSE AUTOEXTEND ON NEXT 5120K MAXSIZE UNLIMITED;




--@c:\oracle\ora92\RDBMS\ADMIN\catalog
--@c:\oracle\ora92\RDBMS\ADMIN\catproc
spool off
--CONNECT system/cursodba

-- En NT esto esta en ORACLE_HOME\dbs
--c:\oracle\ora92\sqlplus\admin\pupbld
