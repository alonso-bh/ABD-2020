-- This lab needs DEMO_RBS rollback segment to be online
-- This also needs the DEMO table in SYSTEM schema



SET TRANSACTION USE ROLLBACK SEGMENT demo_rbs;

INSERT INTO system.dept(deptno,dname) VALUES(1,'Accounts')
/
