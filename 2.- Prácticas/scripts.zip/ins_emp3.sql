-- This lab needs DEMO_RBS rollback segment to be online
-- This also needs the EMP table in SYSTEM schema


TRUNCATE TABLE system.emp
/

SET TRANSACTION USE ROLLBACK SEGMENT demo_rbs;

DECLARE
  no_rbs_ext NUMBER := 0;
BEGIN
  INSERT INTO system.emp(empno,ename) VALUES(1,'Test Data');
  FOR i IN 1..7
  LOOP
     INSERT INTO system.emp
     SELECT * FROM system.emp;
  END LOOP;
  WHILE no_rbs_ext < 5
  LOOP
     UPDATE system.emp
      SET empno=empno+1;
     SELECT extents
      INTO no_rbs_ext
      FROM V$ROLLSTAT
      WHERE usn = (SELECT usn
               FROM v$rollname 
               WHERE name='DEMO_RBS');
  END LOOP;
END;
/
