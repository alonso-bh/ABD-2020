DECLARE
  v_review_loc CLOB;
  v_image_loc BFILE;
  v_text VARCHAR2(500);
  v_amount NUMBER := 53;
BEGIN
  SELECT review, image
    INTO v_review_loc, v_image_loc
    FROM products
    WHERE prod_code=100860
    FOR UPDATE;
  dbms_lob.loadfromfile(v_review_loc,v_image_loc,v_amount);
END;
/
