CREATE TABLE
NLS (c varchar2(10));
insert into nls values ('�');
insert into nls values ('�');
