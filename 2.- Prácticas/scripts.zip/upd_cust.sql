begin  
FOR i IN 1..999
  LOOP
     INSERT INTO system.customers(cust_code,name) 
     VALUES('C0'||to_char(i),'JOCKSPORTS');                

     INSERT INTO system.customers(cust_code,name) 
     VALUES('B0'||to_char(i),'STADIUM SPORTS');            

     INSERT INTO system.customers(cust_code,name) 
     VALUES('B1'||to_char(i),'HOOPS');                     

     INSERT INTO system.customers(cust_code,name) 
     VALUES('B3'||to_char(i),'REBOUND SPORTS');            

     INSERT INTO system.customers(cust_code,name) 
     VALUES('B4'||to_char(i),'THE POWER FORWARD');         

     INSERT INTO system.customers(cust_code,name) 
     VALUES('B5'||to_char(i),'POINT GUARD');               

     INSERT INTO system.customers(cust_code,name) 
     VALUES('B6'||to_char(i),'THE COLISEUM');              

     INSERT INTO system.customers(cust_code,name) 
     VALUES('B7'||to_char(i),'FAST BREAK');                

     INSERT INTO system.customers(cust_code,name) 
     VALUES('B8'||to_char(i),'AL AND BOB''S SPORTS');       

     INSERT INTO system.customers(cust_code,name) 
     VALUES('B9'||to_char(i),'AT BAT');                    

     INSERT INTO system.customers(cust_code,name) 
     VALUES('C1'||to_char(i),'ALL SPORT');                 

     INSERT INTO system.customers(cust_code,name) 
     VALUES('C2'||to_char(i),'GOOD SPORT');                

     INSERT INTO system.customers(cust_code,name) 
     VALUES('C4'||to_char(i),'AL''S PRO SHOP');             

     INSERT INTO system.customers(cust_code,name) 
     VALUES('C5'||to_char(i),'BOB''S FAMILY SPORTS');       

     INSERT INTO system.customers(cust_code,name) 
     VALUES('C6'||to_char(i),'THE ALL AMERICAN');          

     INSERT INTO system.customers(cust_code,name) 
     VALUES('C7'||to_char(i),'HIT, THROW, AND RUN');       

     INSERT INTO system.customers(cust_code,name) 
     VALUES('C8'||to_char(i),'THE OUTFIELD');              

     INSERT INTO system.customers(cust_code,name) 
     VALUES('C9'||to_char(i),'WHEELS AND DEALS');          

     INSERT INTO system.customers(cust_code,name) 
     VALUES('C3'||to_char(i),'JUST BIKES');                

     INSERT INTO system.customers(cust_code,name) 
     VALUES('D0'||to_char(i),'VELO SPORTS');               

     INSERT INTO system.customers(cust_code,name) 
     VALUES('D1'||to_char(i),'JOE''S BIKE SHOP');           

     INSERT INTO system.customers(cust_code,name) 
     VALUES('D2'||to_char(i),'BOB''S SWIM, CYCLE, AND RUN');

     INSERT INTO system.customers(cust_code,name) 
     VALUES('D3'||to_char(i),'CENTURY SHOP');              

     INSERT INTO system.customers(cust_code,name) 
     VALUES('D4'||to_char(i),'THE TOUR');                  

     INSERT INTO system.customers(cust_code,name) 
     VALUES('B2'||to_char(i),'FITNESS FIRST');             
  END LOOP;

END;
/



UPDATE system.customers SET region='West',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='C011';                       
UPDATE system.customers SET region='East',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B121';                       
UPDATE system.customers SET region='East',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B021';                       
UPDATE system.customers SET region='East',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B031';                       
UPDATE system.customers SET region='East',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B041';                       
UPDATE system.customers SET region='West',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B051';                       
UPDATE system.customers SET region='North',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B061';                      
UPDATE system.customers SET region='South',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B071';                      
UPDATE system.customers SET region='North',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B081';                      
UPDATE system.customers SET region='North',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B111';                      
UPDATE system.customers SET region='West',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B121';                       
UPDATE system.customers SET region='East',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B131';                       
UPDATE system.customers SET region='North',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B141';                      
UPDATE system.customers SET region='West',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B151';                       
UPDATE system.customers SET region='North',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B161';                      
UPDATE system.customers SET region='East',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B171';                       
UPDATE system.customers SET region='East',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B181';                       
UPDATE system.customers SET region='East',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B211';                       
UPDATE system.customers SET region='East',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B221';                       
UPDATE system.customers SET region='North',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B231';                      
UPDATE system.customers SET region='South',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B241';                      
UPDATE system.customers SET region='South',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B251';                      
UPDATE system.customers SET region='South',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B261';                      
UPDATE system.customers SET region='North',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B271';                      
UPDATE system.customers SET region='North',name='01234567890123456789012345678901234567890123456789' WHERE cust_code='B281';          
commit;            