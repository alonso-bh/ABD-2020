-- This lab needs DEMO_RBS rollback segment to be online
-- This also needs the EMP table in SYSTEM schema

connect system/manager;

TRUNCATE TABLE emp;

SET TRANSACTION USE ROLLBACK SEGMENT demo_rbs;

DECLARE
  no_rbs_ext NUMBER := 0;
BEGIN
  INSERT INTO emp(empno,ename) VALUES(1,'Test Data');
  FOR i IN 1..7
  LOOP
     INSERT INTO emp
     SELECT * FROM emp;
  END LOOP;
  WHILE no_rbs_ext < 5
  LOOP
     UPDATE emp
      SET empno=empno+1;
     SELECT extents
      INTO no_rbs_ext
      FROM V$ROLLSTAT
      WHERE usn = (SELECT usn
               FROM v$rollname 
               WHERE name='DEMO_RBS');
  END LOOP;
  ROLLBACK;
END;
/
