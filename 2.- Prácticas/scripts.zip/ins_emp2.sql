-- Script ins_emp2.sql to create segments
-- for Lab10, Q6 O8DBA class
-- Created : 16-OCT-97
-- Author  : vvijayan

-- Dependencies :
-- needs script ins_emp.sql

host sqlplus system/manager @ins_emp

