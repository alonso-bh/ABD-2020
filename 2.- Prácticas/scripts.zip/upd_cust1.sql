SET ECHO on

SELECT cust_code, name, region
  FROM system.customers
  WHERE cust_code BETWEEN 'A05' AND 'A07'
/

UPDATE system.customers
  SET name='K + T SPORTS',
      region='East'
  WHERE cust_code='A05'
/
