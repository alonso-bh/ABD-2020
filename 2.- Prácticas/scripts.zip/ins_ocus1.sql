SET ECHO on

INSERT INTO system.orders
VALUES(800,to_date('09-01-97','DD-Mm-YY'),'J01',NULL)
/

INSERT INTO system.customers
VALUES('J01','Sports Unlimited','West')
/
