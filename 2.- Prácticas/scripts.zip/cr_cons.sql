CONNECT system/cursodba

ALTER TABLE system.customers
ADD (CONSTRAINT cust_pk PRIMARY KEY(cust_code)
        DEFERRABLE INITIALLY IMMEDIATE
        USING INDEX TABLESPACE users,
     CONSTRAINT cust_region_ck 
        CHECK (region in ('East','West','North','South')))
/

ALTER TABLE system.orders
ADD(CONSTRAINT ord_pk PRIMARY KEY(ord_id)
       USING INDEX TABLESPACE users,
    CONSTRAINT ord_cc_fk FOREIGN KEY(cust_code)
       REFERENCES customers(cust_code)
       DEFERRABLE INITIALLY IMMEDIATE,
    CONSTRAINT ord_dod_ck CHECK (date_of_dely >= ord_date))
/

ALTER TABLE system.products
ADD CONSTRAINT prod_uk UNIQUE(prod_code) 
    DEFERRABLE DISABLE
/
