-- asn_tts.sql
-- Use for Lab 11 Q3 O8DBA class


-- needs TEMP tablespace

ALTER USER system
TEMPORARY TABLESPACE temp
/
