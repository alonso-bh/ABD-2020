INSERT INTO products VALUES
(100860,'Ace Tennis Racket',36.20,
 'This is a new line of tennis racket',
 BFILENAME('IMAGES','tennis.txt'));
