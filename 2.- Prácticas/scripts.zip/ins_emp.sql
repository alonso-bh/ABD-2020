-- Script ins_emp.sql to create segments
-- for Lab10, Q6 O8DBA class
-- Created : 16-OCT-97
-- Author  : vvijayan

-- Dependencies :
-- needs SYSTEM account to run
-- needs EMP table to be available


INSERT INTO EMP VALUES
(7499,'ALLEN','SALESMAN',7698,
to_date('20-2-1981','dd-mm-yyyy'),1600,300,30);


