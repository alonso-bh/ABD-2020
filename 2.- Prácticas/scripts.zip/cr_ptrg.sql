CREATE OR REPLACE TRIGGER set_odd_even
 BEFORE INSERT OR UPDATE OF no ON system.numbers
 FOR EACH ROW
BEGIN
 IF MOD(:new.no,2)=1
 THEN
   :new.odd_even := 'O' ;
 ELSE
   :new.odd_even := 'E' ;
 END IF;
END;
/

