SET ECHO on

SELECT cust_code, name, region
 FROM system.customers
 WHERE cust_code BETWEEN 'A05' AND 'A07'
/

UPDATE system.customers
 SET name='NEW NAME'
 WHERE cust_code='A06'
/

UPDATE system.customers
 SET region='North'
 WHERE cust_code='A07'
/
